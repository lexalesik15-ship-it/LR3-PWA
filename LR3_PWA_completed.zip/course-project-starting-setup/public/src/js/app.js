var deferredPrompt;

if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("/sw.js")
    .then(function() {
      console.log("Service worker зарегистрирован!");
    })
    .catch(function(error) {
      console.log("Ошибка регистрации Service Worker:", error);
    });
}

window.addEventListener("beforeinstallprompt", function(event) {
  console.log("beforeinstallprompt отменен");
  event.preventDefault();
  deferredPrompt = event;
  return false;
});
